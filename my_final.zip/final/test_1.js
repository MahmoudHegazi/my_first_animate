(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"test_1_atlas_", frames: [[1284,1041,230,124],[1439,935,277,66],[0,798,640,480],[642,798,640,480],[1502,369,150,45],[1589,0,149,87],[1589,184,61,12],[1554,416,76,11],[1706,160,17,14],[1554,449,17,14],[1502,207,149,87],[1653,184,129,49],[1634,416,58,70],[1706,89,17,69],[1554,439,47,8],[1740,78,47,87],[1554,429,69,8],[1502,473,41,37],[1502,416,50,55],[0,0,1500,796],[1439,798,193,135],[1589,89,115,93],[1502,0,85,205],[1653,235,47,87],[1740,0,57,76],[1284,798,153,241],[1502,296,138,71],[1502,512,14,64],[1545,473,25,44]]}
];


// symbols:



(lib.بمهى = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._3121 = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._33063562_443189839485872_4791495228001353728_n = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib._34113001_446960302442159_7177812322180661248_n = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Image = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Image_0 = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Image_1 = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Image_2 = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Image_3 = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Image_4 = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Image_5 = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Image_6 = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Image_7 = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Mesh = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Mesh_0 = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Mesh_1 = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Mesh_2 = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.backkkd = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.backkkdw = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap107 = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.coin_2 = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Final_lab_tools٣٧pngcopy2 = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Front = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Front2 = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Layer0 = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.score = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.tools0٥ = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.tools0٦ = function() {
	this.spriteSheet = ss["test_1_atlas_"];
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.water_point = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#070707").s().p("AkBBqQhrgsAAg+QAAg9BrgsQBrgsCWAAQCXAABrAsQBrAsAAA9QAAA+hrAsQhrAsiXAAQiWAAhrgsg");
	this.shape.setTransform(36.5,15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,73,30);


(lib.water_cover = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFF33").ss(1,1,1).p("AFtAAQAAA+hrAsQhrAsiXAAQiWAAhrgsQhrgsAAg+QAAg9BrgsQBrgsCWAAQCXAABrAsQBrAsAAA9g");
	this.shape.setTransform(-36.5,15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74,-1,75,32);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap107();
	this.instance.parent = this;
	this.instance.setTransform(41,-111,0.104,0.37);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(41,-111,20,50);


(lib.third_moveitems = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap107();
	this.instance.parent = this;
	this.instance.setTransform(-80,0,0.414,0.83);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-80,0,80,112);


(lib.text_note = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Please Close the water", "23px 'Cooper Black'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 28;
	this.text.lineWidth = 183;
	this.text.parent = this;
	this.text.setTransform(-93.5,-57.4);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-186.9,-59.4,187,59.5);


(lib.Symbolb1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4).call(this.frame_4).wait(1));

	// Layer_2
	this.text = new cjs.Text("", "8px '_sans'");
	this.text.textAlign = "center";
	this.text.lineHeight = 11;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(20.6,2.3,0.37,0.515,0,-0.9,0);

	this.timeline.addTween(cjs.Tween.get(this.text).to({_off:true},1).wait(4));

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0063ED").s().p("AgNCPIgzkdIBNAAIA0Edg");
	this.shape.setTransform(37.1,24.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0063ED").s().p("AhDh+IBNAAQATB+AnB7IhQAEQgih1gViIg");
	this.shape_1.setTransform(37.5,22.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0063ED").s().p("AhHhtIBOAAQAMBtA1BnIhTAHQgshagQiBg");
	this.shape_2.setTransform(37.8,21);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0063ED").s().p("AhKhdIBNAAQAGBdBCBUIhVAKQg1g/gLh8g");
	this.shape_3.setTransform(38.2,19.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0063ED").s().p("AhOhNIBOAAQAABMBPBBIhYAOQg+glgHh2g");
	this.shape_4.setTransform(38.6,17.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).wait(1));

	// Layer_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(0,99,237,0.569)").s().p("AgOCPIg0kdIBRAAIA0Edg");
	this.shape_5.setTransform(37,24.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0063ED").s().p("ABICPIg0kdIBPAAIA0EdgAgNCPIg0kdIBOAAIA0EdgAhiCPIg0kdIBPAAIAzEdg");
	this.shape_6.setTransform(19.5,24.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCCCC").s().p("ADNAxIgZAAIhSAAIgJAAIhPAAIgHAAIhOAAIgGAAIhPAAIgbAAIAAgDIgShfIGJAAIASBig");
	this.shape_7.setTransform(20.6,5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["test_1_atlas_"],19), null, new cjs.Matrix2D(1,0,0.18,1,-822.5,-402.8)).s().p("AinCeIg5k7IABAEIAaAAIA0EcIBOAAIgzkcIAGAAIA0EcIBOAAIgzkcIAHAAIAzEcIBPAAIg0kcIAJAAIAzEcIBTAAIg0kcIAaAAIA4E3g");
	this.shape_8.setTransform(24.2,25.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]}).wait(5));

	// Layer_3_copy
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#666666").ss(0.1,1,1).p("AgojDIAIgTIBJGWIgKAXg");
	this.shape_9.setTransform(3.3,21.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#666666").s().p("AgojDIAIgTIBJGWIgKAXg");
	this.shape_10.setTransform(3.3,21.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9}]}).to({state:[]},1).wait(4));

	// Layer_3
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#666666").ss(0.1,1,1).p("Ai/gKIgJAVIGBAAIAQgVg");
	this.shape_11.setTransform(26.6,42.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#666666").s().p("AjIALIAJgVIGIAAIgQAVg");
	this.shape_12.setTransform(26.6,42.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11}]}).to({state:[]},1).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.7,-0.6,49.5,45);


(lib.Symbol91 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Final_lab_tools٣٧pngcopy2();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.453,0.453);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol91, new cjs.Rectangle(0,0,38.6,93), null);


(lib.Symbol11f = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.بمهى();
	this.instance.parent = this;
	this.instance.setTransform(5.2,0,0.276,0.276,8.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol11f, new cjs.Rectangle(0,0,67.8,43.4), null);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		createjs.Sound.stop("water");
		// createjs.Sound.play("water");
	}
	this.frame_1 = function() {
		this.stop();
		
		createjs.Sound.play("water");
		 var myInstance = createjs.Sound.play("water", {interrupt: createjs.Sound.INTERRUPT_ANY, loop:-1});
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// tools_0٦
	this.instance = new lib.tools0٦();
	this.instance.parent = this;
	this.instance.setTransform(0,155,0.882,0.882);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1));

	// tools_0٥
	this.instance_1 = new lib.tools0٥();
	this.instance_1.parent = this;
	this.instance_1.setTransform(6,142,0.882,0.882);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},1).wait(1));

	// Layer_0
	this.instance_2 = new lib.Layer0();
	this.instance_2.parent = this;
	this.instance_2.setTransform(9,0,0.882,0.882);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

	// tools_0٧
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#5C97B9","#EBF6F7","#5D99BC"],[0,0.463,1],-4,-0.1,4.1,-0.1).s().p("AgoLOQANq+gNrdIBQAAIAAWbg");
	this.shape.setTransform(133.5,137.3);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(6,0,138,212.6);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#00FF00").ss(6,1,1).p("AU7AAQAACimIByQmIByorAAQoqAAmIhyQmIhyAAiiQAAihGIhyQGIhyIqAAQIrAAGIByQGIByAAChg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#660066").s().p("AuyETQmIhxABiiQgBihGIhxQGIhzIqAAQIrAAGIBzQGIBxgBChQABCimIBxQmIBzorAAQoqAAmIhzg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(-136.8,-41.9,273.7,83.9), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.score();
	this.instance.parent = this;
	this.instance.setTransform(-114.1,-58.7,1.654,1.654);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-114.1,-58.7,228.2,117.4);


(lib.peace_mg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap107();
	this.instance.parent = this;
	this.instance.setTransform(53,-41,0.104,0.741);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(53,-41,20,100);


(lib.mywater_first = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0033CC").s().p("AAfCvIhfgEQgTgBgOgzQgNgzAAhGQAAhHANgzQAOgyASAAQAUAABPAlQBRAlgECKQgFCJhIAAIgDAAg");
	this.shape.setTransform(-48.6,21.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-59.6,3.8,22.2,35);


(lib.myshown = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0033CC").s().p("AxuGLIAAsVMAjdAAAIAAMVg");
	this.shape.setTransform(-113.5,-39.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-226.9,-79,227,79);


(lib.msmarcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#C6C2C1","#CCCCCC"],[0,1],0,0,0,0,0,6.3).s("#C9C7C6").ss(1,1,1).de(-18.1,-6.3,36.2,12.7);
	this.shape.setTransform(180,165.9,1.204,1.086);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A19A98").s("#C7C3C2").ss(0.1,1,1).de(-18.1,-6.3,36.2,12.7);
	this.shape_1.setTransform(180,167.9,1.204,1.086);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#C9C7C6").ss(0.1,1,1).p("AhmJhIAAzBIDNAAIAATB");
	this.shape_2.setTransform(180,227.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#C6C2C1","#FFFFFF","#CCCCCC"],[0,0.482,1],-10.2,-10.4,10.3,-10.4).s().p("AhmH5IAAzBIDNAAIAATBIgBABIAAgBIhmDQg");
	this.shape_3.setTransform(180,238.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.msmarcopy, new cjs.Rectangle(157.3,158,45.6,151.5), null);


(lib.Path_3copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5D5D4").s().p("AiJAaQg5gKAAgQQAAgOA5gLQA6gLBPAAQBRAAA5ALQA5ALAAAOQAAAQg5AKQg4AKhSAAQhQAAg5gKg");
	this.shape.setTransform(19.5,3.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_3copy2, new cjs.Rectangle(0,0,39,7.3), null);


(lib.Path_2copy5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#35383B","#DBD8D9","#E0DDDE","#F7F6F7","#E2E4E7","#AEB7C0"],[0,0.541,0.557,0.757,0.831,0.98],-7,-1.6,4.5,10.4).s().p("AggB3QgTgIgJgLQgLgOAAgbQgBgoADiNQAFCuADAPQADASAQAMQAQALAWACQAPABAYgGQAbgHALAAQgOADgbAJIghALIgLACQgKAAgKgEg");
	this.shape.setTransform(7.2,12.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_2copy5, new cjs.Rectangle(0,0,14.5,24.5), null);


(lib.Path_2copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#35383B","#DBD8D9","#E0DDDE","#F7F6F7","#E2E4E7","#AEB7C0"],[0,0.541,0.557,0.757,0.831,0.98],-7,-1.6,4.5,10.4).s().p("AggB3QgTgIgJgLQgLgOAAgbQgBgoADiNQAFCuADAPQADASAQAMQAQALAWACQAPABAYgGQAbgHALAAQgOADgbAJIghALIgLACQgKAAgKgEg");
	this.shape.setTransform(7.2,12.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_2copy2, new cjs.Rectangle(0,0,14.5,24.5), null);


(lib.Path_1copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#AEB7C0","#E0DDDE","#F7F6F7","#E2E4E7","#AEB7C0"],[0.063,0.471,0.922,0.941,0.98],0.2,0,0,0.2,0,10.5).s().p("AAgABQgngEgjADQgkAFgUABQghACgLgDQAMACA3gJQAlgHAxADQAYACAzAGQAgAFAZABQgzgBg8gGg");
	this.shape.setTransform(14.6,0.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1copy3, new cjs.Rectangle(0.4,0,28.6,1.6), null);


(lib.Path_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#AEB7C0","#E0DDDE","#F7F6F7","#E2E4E7","#AEB7C0"],[0.063,0.471,0.922,0.941,0.98],0.2,0,0,0.2,0,10.5).s().p("AAgABQgngEgjADQgkAFgUABQghACgLgDQAMACA3gJQAlgHAxADQAYACAzAGQAgAFAZABQgzgBg8gGg");
	this.shape.setTransform(14.6,0.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1, new cjs.Rectangle(0.4,0,28.6,1.6), null);


(lib.Path_0copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.Path_0copy4, null, null);


(lib.Path_0copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.Path_0copy2, null, null);


(lib.Group_1copy7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A1EE").s().p("AipD9QgygDgHgvIADhMQgDhBgBhKQAAiWAOg0QAIgeCmgIQCqgKBFAiQAKAFADAIQADAGAAANIAJFDIADBMQgHAvgyADQglACiFAAQiFAAglgCg");
	this.shape.setTransform(22.8,25.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1copy7, new cjs.Rectangle(0.1,0,45.6,51.1), null);


(lib.Group_1copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A1EE").s().p("AipD9QgygDgHgvIADhMQgDhBgBhKQAAiWAOg0QAIgeCmgIQCqgKBFAiQAKAFADAIQADAGAAANIAJFDIADBMQgHAvgyADQglACiFAAQiFAAglgCg");
	this.shape.setTransform(22.8,25.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1copy3, new cjs.Rectangle(0.1,0,45.6,51.1), null);


(lib.ClipGroup_38 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlJBGIAAiLIKTAAIAACLg");
	mask.setTransform(33,7);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDFEFF").s().p("Aj5BGQg6hBgWhKIKTAAIghBJQgSAogTAag");
	this.shape.setTransform(33,7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_38, new cjs.Rectangle(0,0,66,14), null);


(lib.ClipGroup_37 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiJClIAAlKIETAAIAAFKg");
	mask.setTransform(13.8,17);

	// Layer_3
	this.instance = new lib.Image_7();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_37, new cjs.Rectangle(0,0.4,27.5,33.1), null);


(lib.ClipGroup_33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkzByIAAjjIJnAAIAADjg");
	mask.setTransform(30.9,11.8);

	// Layer_3
	this.instance = new lib.Image_6();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_33, new cjs.Rectangle(0.1,0.4,61.7,22.8), null);


(lib.ClipGroup_29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AliDNIAAmZILFAAIAAGZg");
	mask.setTransform(35.8,20.8);

	// Layer_3
	this.instance = new lib.Image_5();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_29, new cjs.Rectangle(0.3,0.4,71,40.9), null);


(lib.ClipGroup_25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AglAgIAAg/IBLAAIAAA/g");
	mask.setTransform(4.3,3.4);

	// Layer_3
	this.instance = new lib.Image_4();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_25, new cjs.Rectangle(0.5,0.2,7.6,6.5), null);


(lib.ClipGroup_21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgmAgIAAg/IBNAAIAAA/g");
	mask.setTransform(4,3.5);

	// Layer_3
	this.instance = new lib.Image_3();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_21, new cjs.Rectangle(0.1,0.3,7.8,6.4), null);


(lib.ClipGroup_17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ai0AYIAAgvIFpAAIAAAvg");
	mask.setTransform(18.1,2.7);

	// Layer_3
	this.instance = new lib.Image_2();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_17, new cjs.Rectangle(0,0.3,36.2,4.8), null);


(lib.ClipGroup_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiRAbIAAg1IEiAAIAAA1g");
	mask.setTransform(14.7,2.7);

	// Layer_3
	this.instance = new lib.Image_1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_13, new cjs.Rectangle(0.1,0,29.1,5.5), null);


(lib.ClipGroup_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AliDNIAAmZILFAAIAAGZg");
	mask.setTransform(35.6,20.8);

	// Layer_3
	this.instance = new lib.Image_0();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9, new cjs.Rectangle(0.1,0.4,71,40.9), null);


(lib.ClipGroup_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AljBrIAAjVILHAAIAADVg");
	mask.setTransform(36,10.7);

	// Layer_3
	this.instance = new lib.Image();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.48,0.48);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6, new cjs.Rectangle(0.4,0.1,71.1,21.3), null);


(lib.ClipGroup_4copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiIAPQg4gGAAgJQAAgIA4gGQA5gGBPAAQBQAAA5AGQA4AGAAAIQAAAJg4AGQg5AGhQAAQhPAAg5gGg");
	mask.setTransform(19.3,2.1);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#292929","#292929","#323131","#494847","#656362","#848181","#A3A0A0","#BFBDBD","#D8D6D6","#EAE9E9","#F9F8F8","#FFFFFF"],[0,0.365,0.38,0.412,0.451,0.49,0.533,0.58,0.639,0.702,0.792,1],0,0,0,0,0,19.1).s().p("AjAAVIAAgpIGBAAIAAApg");
	this.shape.setTransform(19.3,2.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4copy, new cjs.Rectangle(0,0,38.7,4.3), null);


(lib.ClipGroup_2copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiJAPQg6gGAAgJQAAgIA6gGQA5gGBQAAQBRAAA6AGQA5AGAAAIQAAAJg5AGQg6AGhRAAQhQAAg5gGg");
	mask.setTransform(19.6,2.1);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#292929","#292929","#2E2E2E","#494747","#696666","#8C8989","#AEACAC","#CDCBCA","#E4E3E3","#F6F5F5","#FFFFFF"],[0,0.345,0.361,0.427,0.494,0.565,0.639,0.714,0.796,0.886,1],0,0,0,0,0,19.4).s().p("AjDAVIAAgpIGHAAIAAApg");
	this.shape.setTransform(19.6,2.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2copy, new cjs.Rectangle(0,0,39.2,4.3), null);


(lib.textbody = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.myshown();
	this.instance.parent = this;
	this.instance.setTransform(-113.5,-39.5,1,1,0,0,0,-113.5,-39.5);
	new cjs.ButtonHelper(this.instance, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-226.9,-79,227,79);


(lib.Symbol46 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["test_1_atlas_"],24), null, new cjs.Matrix2D(0.569,0,0,0.545,-16.2,-22.1)).s().p("AihDBIAAmBIFCAAIAAGBg");
	this.shape.setTransform(34.1,22.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	// Layer_3
	this.instance = new lib.Symbol91();
	this.instance.parent = this;
	this.instance.setTransform(26.8,0.8,1,1,0,0,0,19.3,46.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(1));

	// Layer_4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["test_1_atlas_"],24), null, new cjs.Matrix2D(0.569,0,0,0.545,-16.2,-1.4)).s().p("AihAOIAAgbIFCAAIAAAbg");
	this.shape_1.setTransform(34.1,1.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(2));

	// Layer_2
	this.instance_1 = new lib.Path_2copy2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(25.7,33.7,0.622,0.572,0,0,0,7.4,13.5);
	this.instance_1.alpha = 0.602;

	this.instance_2 = new lib.Path_0copy2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(44.4,40.4,0.621,0.572,0,0,0,6.4,6.4);
	this.instance_2.alpha = 0.5;

	this.instance_3 = new lib.Path_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(34.9,39.9,0.621,0.572,0,0,0,21,7.2);
	this.instance_3.alpha = 0.5;

	this.instance_4 = new lib.Group_1copy3();
	this.instance_4.parent = this;
	this.instance_4.setTransform(34.1,26.8,0.622,0.572,0,0,0,22.9,25.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(7.5,-45.7,42.8,93);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("start", "39px 'Arial'", "#660099");
	this.text.textAlign = "center";
	this.text.lineHeight = 46;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(0,-21.7);

	this.instance = new lib.score();
	this.instance.parent = this;
	this.instance.setTransform(-114.1,-58.7,1.654,1.654);

	this.instance_1 = new lib.Symbol2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.filters = [new cjs.ColorFilter(0.38, 0.38, 0.38, 1, 0, 0, 0, 0)];
	this.instance_1.cache(-116,-61,232,121);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance,p:{scaleX:1.654,scaleY:1.654,x:-114.1,y:-58.7}},{t:this.text,p:{scaleX:1,scaleY:1,y:-21.7,color:"#660099"}}]}).to({state:[{t:this.instance,p:{scaleX:2.135,scaleY:2.135,x:-147,y:-76}},{t:this.text,p:{scaleX:1.291,scaleY:1.291,y:-28,color:"#660099"}}]},1).to({state:[{t:this.instance_1},{t:this.text,p:{scaleX:1,scaleY:1,y:-21.7,color:"#66FF00"}}]},1).to({state:[{t:this.instance,p:{scaleX:1.654,scaleY:1.654,x:-114.1,y:-58.7}},{t:this.text,p:{scaleX:1,scaleY:1,y:-21.7,color:"#660099"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-114.1,-58.7,228.2,117.4);


(lib.Scene_1_Layer_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_7
	this.water_cover = new lib.water_cover();
	this.water_cover.name = "water_cover";
	this.water_cover.parent = this;
	this.water_cover.setTransform(167.8,304.7,1,1,0,0,0,-36.5,15);
	this.water_cover.visible = false;
	new cjs.ButtonHelper(this.water_cover, 0, 1, 1);

	this.water_point = new lib.water_point();
	this.water_point.name = "water_point";
	this.water_point.parent = this;
	this.water_point.setTransform(166.6,305.8,0.959,1.067,0,0,0,36.8,15.1);
	this.water_point.visible = false;
	new cjs.ButtonHelper(this.water_point, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.water_point},{t:this.water_cover}]}).wait(2));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Layer_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_6
	this.hotp_1 = new lib.Symbol4();
	this.hotp_1.name = "hotp_1";
	this.hotp_1.parent = this;
	this.hotp_1.setTransform(391.2,236.7,0.681,0.488,0,0,0,0,0.1);
	this.hotp_1.visible = false;
	this.hotp_1.filters = [new cjs.ColorFilter(0.51, 0.51, 0.51, 1, 49.98, 124.95, 0, 0)];
	this.hotp_1.cache(-139,-44,278,88);

	this.timeline.addTween(cjs.Tween.get(this.hotp_1).wait(2));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Layer_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_5
	this.hanfi_1 = new lib.Symbol6();
	this.hanfi_1.name = "hanfi_1";
	this.hanfi_1.parent = this;
	this.hanfi_1.setTransform(97.4,144.7,1.05,1.049,0,0,0,71.5,106.9);

	this.peace_mg = new lib.peace_mg();
	this.peace_mg.name = "peace_mg";
	this.peace_mg.parent = this;
	this.peace_mg.setTransform(617,150.5,1,1,0,0,0,20,17.5);
	this.peace_mg.visible = false;
	new cjs.ButtonHelper(this.peace_mg, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.peace_mg},{t:this.hanfi_1}]}).wait(2));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Layer_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.start_1 = new lib.Symbol1();
	this.start_1.name = "start_1";
	this.start_1.parent = this;
	this.start_1.setTransform(451.1,49,0.749,0.749,0,0,0,-0.1,-0.2);
	new cjs.ButtonHelper(this.start_1, 0, 1, 2, false, new lib.Symbol1(), 3);

	this.timeline.addTween(cjs.Tween.get(this.start_1).wait(2));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Actions = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Actions
	this.mytext_note = new lib.text_note();
	this.mytext_note.name = "mytext_note";
	this.mytext_note.parent = this;
	this.mytext_note.setTransform(168.6,432.2,1,1,0,0,0,-93.5,-29.8);
	this.mytext_note.visible = false;
	new cjs.ButtonHelper(this.mytext_note, 0, 1, 1);

	this.text_body = new lib.textbody();
	this.text_body.name = "text_body";
	this.text_body.parent = this;
	this.text_body.setTransform(168.5,429.5,1,1,0,0,0,-113.5,-39.5);
	this.text_body.visible = false;
	new cjs.ButtonHelper(this.text_body, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_body},{t:this.mytext_note}]}).wait(2));

}).prototype = p = new cjs.MovieClip();


(lib.mybeksss = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.stop();
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
		this.stop();
	}
	this.frame_10 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(8).call(this.frame_9).wait(1).call(this.frame_10).wait(9).call(this.frame_19).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["test_1_atlas_"],24), null, new cjs.Matrix2D(0.569,0,0,0.545,-16.2,-22.1)).s().p("AigDBIAAmBIFBAAIAAGBg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(20));

	// Layer_2
	this.instance = new lib.mywater_first();
	this.instance.parent = this;
	this.instance.setTransform(9,7.6,1.299,0.395,0,0,0,-42,19.2);
	this.instance._off = true;
	new cjs.ButtonHelper(this.instance, 0, 1, 1);

	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(6,-6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regY:19.1,scaleY:1.05,y:-3.3},8).to({_off:true},1).wait(10));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(10).to({_off:false},0).to({scaleY:0.9,x:-49,y:74.2},9).wait(1));

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["test_1_atlas_"],24), null, new cjs.Matrix2D(0.569,0,0,0.545,-16.2,-1.4)).s().p("AigAOIAAgbIFBAAIAAAbg");
	this.shape_1.setTransform(0,-20.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(20));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.1,-22.1,32.3,41.5);


(lib.Symbol42copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Path_3copy2();
	this.instance.parent = this;
	this.instance.setTransform(22.8,4.6,1,1,0,0,0,19.5,3.6);
	this.instance.alpha = 0.129;

	this.instance_1 = new lib.Path_2copy5();
	this.instance_1.parent = this;
	this.instance_1.setTransform(9.4,37.3,1,1,0,0,0,7.3,12.3);
	this.instance_1.alpha = 0.602;

	this.instance_2 = new lib.Path_0copy4();
	this.instance_2.parent = this;
	this.instance_2.setTransform(39.2,49.9);
	this.instance_2.alpha = 0.5;

	this.instance_3 = new lib.Path_1copy3();
	this.instance_3.parent = this;
	this.instance_3.setTransform(24.3,49.1,1,1,0,0,0,14.7,0.8);
	this.instance_3.alpha = 0.5;

	this.instance_4 = new lib.Group_1copy7();
	this.instance_4.parent = this;
	this.instance_4.setTransform(22.8,25.5,1,1,0,0,0,22.8,25.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol42copy, new cjs.Rectangle(0,0,45.6,51.1), null);


(lib.Symbol41copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(7));

	// Layer_2
	this.text = new cjs.Text("زيت", "19px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 23;
	this.text.lineWidth = 49;
	this.text.parent = this;
	this.text.setTransform(34.3,53.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1B1464").s().p("AjqBWIAAjHQDSAlEDglIAADHQiAAch1AAQh1AAhrgcg");
	this.shape.setTransform(34.6,64.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text}]}).to({state:[]},1).wait(6));

	// Layer_1
	this.instance = new lib.Front();
	this.instance.parent = this;
	this.instance.setTransform(11,13);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(6));

	// Layer_4
	this.instance_1 = new lib.Symbol42copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(34.5,70.2,1,1,0,0,0,22.8,25.5);
	this.instance_1.filters = [new cjs.ColorFilter(0.31, 0.31, 0.31, 1, 134.55, 160.08, 0, 0)];
	this.instance_1.cache(-2,-2,50,55);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},1).wait(6));

	// Layer_3
	this.instance_2 = new lib.Mesh_0();
	this.instance_2.parent = this;
	this.instance_2.setTransform(12,90.4);

	this.instance_3 = new lib.Mesh();
	this.instance_3.parent = this;
	this.instance_3.setTransform(17.6,16.2);

	this.instance_4 = new lib.Mesh_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(10.9,13.1);

	this.instance_5 = new lib.Mesh_2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(0,94.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]}).to({state:[]},1).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,13,69,89.3);


(lib.Symbol4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{sart:6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.stop();
	}
	this.frame_1 = function() {
		//this.stop();
	}
	this.frame_2 = function() {
		//this.stop();
	}
	this.frame_3 = function() {
		//this.stop();
	}
	this.frame_8 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}
	this.frame_10 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(5).call(this.frame_8).wait(1).call(this.frame_9).wait(1).call(this.frame_10).wait(2));

	// Layer_7
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["test_1_atlas_"],3), null, new cjs.Matrix2D(0.985,0.173,-0.173,0.985,-371.3,-348.1)).s().p("Aj9DYIAAmvIAmAAIAAAaIHNAAIAAgaIAIAAIAAGvg");
	this.shape_2.setTransform(14.5,118.7);
	this.shape_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1).to({_off:false},0).to({_off:true},10).wait(1));

	// klutgitt8Layer_3
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["test_1_atlas_"],1), null, new cjs.Matrix2D(1.089,-0.071,0.141,2.159,-155.5,-61.4)).s().p("A4SplMAvIgDFIBdWQMgvIADFg");
	this.shape_3.setTransform(-105.7,100.3);

	this.flin_1 = new lib.Symbol11f();
	this.flin_1.name = "flin_1";
	this.flin_1.parent = this;
	this.flin_1.setTransform(-95.3,100.4,3.842,3.762,-3.7,0,0,33.9,21.7);

	this.msm_1 = new lib.msmarcopy();
	this.msm_1.name = "msm_1";
	this.msm_1.parent = this;
	this.msm_1.setTransform(-64.4,78.7,2.057,2.057,-90.7,0,0,180.2,234.2);

	this.blu_paper = new lib.Symbolb1();
	this.blu_paper.name = "blu_paper";
	this.blu_paper.parent = this;
	this.blu_paper.setTransform(-121.1,23,4.87,4.126,0,-37.2,0,23.6,20.8);

	this.instance = new lib.coin_2();
	this.instance.parent = this;
	this.instance.setTransform(-112,13,1.319,1.427);

	this.box_22 = new lib.Symbol41copy();
	this.box_22.name = "box_22";
	this.box_22.parent = this;
	this.box_22.setTransform(-29.6,143.4,3.178,3.18,0,0,0,38.8,54.5);

	this.instance_1 = new lib.backkkdw();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-86,12,2.502,2.502);

	this.instance_2 = new lib.backkkd();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-52.9,19.3,2.856,2.856,21.2);

	this.peace_mg = new lib.peace_mg();
	this.peace_mg.name = "peace_mg";
	this.peace_mg.parent = this;
	this.peace_mg.setTransform(-232,125.1,5,1.714,0,0,0,20,17.5);
	new cjs.ButtonHelper(this.peace_mg, 0, 1, 1);

	this.instance_3 = new lib.Bitmap107();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-72,-31,0.518,1);

	this.instance_4 = new lib.Front2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-85,-41,2.281,1.974);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.flin_1}]},1).to({state:[{t:this.msm_1}]},1).to({state:[{t:this.blu_paper}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.box_22}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.peace_mg}]},1).to({state:[{t:this.instance_4},{t:this.instance_3}]},1).to({state:[]},1).wait(1));

	// Layer_5
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["test_1_atlas_"],2), null, new cjs.Matrix2D(0.952,0.305,-0.305,0.952,-345.5,-482.1)).s().p("AgdFiQABgWgGgXQgLgvgsg7QgGgJgHgEQgKgEgGAFQgLgRgVgOQgOgJgagNIgxgWIghg7IgoAYIhSgjQgtgRgRgKQgKgGgjgWIi0iEQhIg0gjgdQhphUhShiQgOgPACgLQABgKARgLIBNgzQArgbAPgXQASgXABggIAtgaImZq3ICZhaIgIgMICHhQIAIANIAACqIBEAAIAAAUIAsAAIDZFxIAxgdQAFAIANAGQAKAEAXAAIAmACQAcACAMgGQAUACAbAHQAeAJAOACQA4ANAlgHQAhgMAQgCIAVAAIAUAAQAZgFANABQAOACAIAAQAKAAASgJIFhJaICIhQILJS8IoSLXg");
	this.shape_4.setTransform(134.8,173.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["test_1_atlas_"],3), null, new cjs.Matrix2D(0.985,0.173,-0.173,0.985,-359.9,-263.9)).s().p("AjeEKIoIAAIARhfIADgTIBKmhIH4AAIN3CcIAAF3g");
	this.shape_5.setTransform(11.4,45.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["test_1_atlas_"],3), null, new cjs.Matrix2D(0.985,0.173,-0.173,0.985,-372.8,-327.8)).s().p("AjmANIAAgZIHNAAIAAAZg");
	this.shape_6.setTransform(16,98.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["test_1_atlas_"],3), null, new cjs.Matrix2D(0.985,0.173,-0.173,0.985,-431.1,-432.7)).s().p("ADFTiIAAyCImpAAIAApEIpvAAIAAiRIH9AAIAAmwIgIAAInPAAIgmAAIAAj2IPFAAIAcAAIAAgpIBPAAIAAGeIFvAAIAAHCIFkAAIAAE0IICAAIkZY/gA2x17IADgSIBnAAIgDASg");
	this.shape_7.setTransform(74.3,203.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4}]}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]},1).to({state:[]},10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(16.8,22.4,236,302.2);


(lib.Group_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_38();
	this.instance.parent = this;
	this.instance.setTransform(33,7,1,1,0,0,0,33,7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_0, new cjs.Rectangle(0,0,66,14), null);


(lib.ClipGroup_36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiJClIAAlKIETAAIAAFKg");
	mask.setTransform(13.8,17);

	// Layer_3
	this.instance = new lib.ClipGroup_37();
	this.instance.parent = this;
	this.instance.setTransform(13.9,16.8,1,1,0,0,0,13.9,16.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_36, new cjs.Rectangle(0,0.4,27.5,33.1), null);


(lib.ClipGroup_35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiJCmQANgeAVgZIAigpIAIgLQAhgkARgbQAegzAHhHIACgWQA0AAArgMIAPgFIgDAYQgKBIgiA4QgTAdgiAoIgJAMIghAsQgTAZgKAdg");
	mask.setTransform(13.8,16.6);

	// Layer_3
	this.instance = new lib.ClipGroup_36();
	this.instance.parent = this;
	this.instance.setTransform(13.9,16.4,1,1,0,0,0,13.9,16.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_35, new cjs.Rectangle(0,0,27.5,33.1), null);


(lib.ClipGroup_34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiJCmIAAlLIETAAIAAFLg");
	mask.setTransform(13.8,16.6);

	// Layer_3
	this.instance = new lib.ClipGroup_35();
	this.instance.parent = this;
	this.instance.setTransform(13.9,16.4,1,1,0,0,0,13.9,16.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_34, new cjs.Rectangle(0,0,27.5,33.1), null);


(lib.ClipGroup_32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkzByIAAjjIJnAAIAADjg");
	mask.setTransform(30.9,11.8);

	// Layer_3
	this.instance = new lib.ClipGroup_33();
	this.instance.parent = this;
	this.instance.setTransform(30.9,11.8,1,1,0,0,0,30.9,11.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_32, new cjs.Rectangle(0.1,0.4,61.7,22.8), null);


(lib.ClipGroup_31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah3BpQg5gJgfgQIgVgdQhHhkgHgvIgBgLQAhAmBYAVQBUAVBmgCQBegCBQgUQBWgWAwgoIgBAMQgHAdgeAxQgfAwghAlQgKALgKAIQhCAgh7ABIgHAAQg6AAgzgJg");
	mask.setTransform(30.8,11.4);

	// Layer_3
	this.instance = new lib.ClipGroup_32();
	this.instance.parent = this;
	this.instance.setTransform(30.8,11.5,1,1,0,0,0,30.9,11.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_31, new cjs.Rectangle(0,0,61.7,22.8), null);


(lib.ClipGroup_30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkzByIAAjjIJnAAIAADjg");
	mask.setTransform(30.8,11.4);

	// Layer_3
	this.instance = new lib.ClipGroup_31();
	this.instance.parent = this;
	this.instance.setTransform(30.9,11.4,1,1,0,0,0,30.9,11.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_30, new cjs.Rectangle(0,0,61.7,22.8), null);


(lib.ClipGroup_28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AliDNIAAmZILFAAIAAGZg");
	mask.setTransform(35.8,20.8);

	// Layer_3
	this.instance = new lib.ClipGroup_29();
	this.instance.parent = this;
	this.instance.setTransform(35.8,20.9,1,1,0,0,0,35.8,20.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_28, new cjs.Rectangle(0.3,0.4,71,40.9), null);


(lib.ClipGroup_27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhcDIQgsgFgBgHQAAgEgDgHQgDgJgIgJQgHgKgIgEQgngZgbgaQgmglgagvQgcgzgQhLQgMg0gCgkQAMAWBqALQBiALCIAAQCXAABogNQBbgMALgTQAAAcgRBFQgTBQgXAlQgeAzgcAbQgWAVgtAfQgOAJgHALQgHAIgDAJIgCALQgFAIgqAEQgnAFg2AAQg1AAglgFg");
	mask.setTransform(35.5,20.5);

	// Layer_3
	this.instance = new lib.ClipGroup_28();
	this.instance.parent = this;
	this.instance.setTransform(35.6,20.6,1,1,0,0,0,35.8,20.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_27, new cjs.Rectangle(0,0,71,41), null);


(lib.ClipGroup_24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AglAgIAAg/IBLAAIAAA/g");
	mask.setTransform(4.3,3.4);

	// Layer_3
	this.instance = new lib.ClipGroup_25();
	this.instance.parent = this;
	this.instance.setTransform(4,3.4,1,1,0,0,0,4,3.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_24, new cjs.Rectangle(0.5,0.2,7.6,6.5), null);


(lib.ClipGroup_23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgVAeQAHgOgBgPQgCgLgEgEQgFgFgLgCQAwgFAJgDIASgCQgUAOgEAEQgVATgBAVQAAACgFACIgCABIgGgCg");
	mask.setTransform(3.8,3.2);

	// Layer_3
	this.instance = new lib.ClipGroup_24();
	this.instance.parent = this;
	this.instance.setTransform(3.6,3.2,1,1,0,0,0,4,3.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_23, new cjs.Rectangle(0,0,7.6,6.4), null);


(lib.ClipGroup_22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AglAgIAAg/IBLAAIAAA/g");
	mask.setTransform(3.8,3.2);

	// Layer_3
	this.instance = new lib.ClipGroup_23();
	this.instance.parent = this;
	this.instance.setTransform(3.6,3.1,1,1,0,0,0,3.6,3.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_22, new cjs.Rectangle(0.1,0,7.6,6.4), null);


(lib.ClipGroup_20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgmAgIAAg/IBNAAIAAA/g");
	mask.setTransform(4,3.5);

	// Layer_3
	this.instance = new lib.ClipGroup_21();
	this.instance.parent = this;
	this.instance.setTransform(4,3.4,1,1,0,0,0,4,3.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_20, new cjs.Rectangle(0.1,0.3,7.8,6.4), null);


(lib.ClipGroup_19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AAOAfQgDgCgBgCQgCgUgVgUIgZgRIAUABQAJADAwAFQgLACgFAFQgEAEgBALQgCAPAHAOIgGABIgDAAg");
	mask.setTransform(3.9,3.1);

	// Layer_3
	this.instance = new lib.ClipGroup_20();
	this.instance.parent = this;
	this.instance.setTransform(4,3.2,1,1,0,0,0,4,3.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_19, new cjs.Rectangle(0,0,7.8,6.3), null);


(lib.ClipGroup_18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgmAfIAAg+IBNAAIAAA+g");
	mask.setTransform(3.9,3.2);

	// Layer_3
	this.instance = new lib.ClipGroup_19();
	this.instance.parent = this;
	this.instance.setTransform(4,3.1,1,1,0,0,0,4,3.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_18, new cjs.Rectangle(0,0,7.8,6.3), null);


(lib.ClipGroup_16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ai0AYIAAgvIFpAAIAAAvg");
	mask.setTransform(18.1,2.7);

	// Layer_3
	this.instance = new lib.ClipGroup_17();
	this.instance.parent = this;
	this.instance.setTransform(18.3,2.6,1,1,0,0,0,18.3,2.6);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_16, new cjs.Rectangle(0,0.3,36.2,4.8), null);


(lib.ClipGroup_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhJAWQg1gDgVgEQAAgBgEgGQgGgHgDgBQgUgLAAgBQAQABBGgFQBPgGAOAAQAKgBBUAFQBKAFAOgDQAAACgWAMIgKAIQgHAGAAACQgRADg3ADQgxADgWAAIgLAAIg9gBg");
	mask.setTransform(18.1,2.4);

	// Layer_3
	this.instance = new lib.ClipGroup_16();
	this.instance.parent = this;
	this.instance.setTransform(18.3,2.3,1,1,0,0,0,18.3,2.6);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_15, new cjs.Rectangle(0,0.1,36.2,4.7), null);


(lib.ClipGroup_14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ai0AXIAAgtIFpAAIAAAtg");
	mask.setTransform(18.1,2.4);

	// Layer_3
	this.instance = new lib.ClipGroup_15();
	this.instance.parent = this;
	this.instance.setTransform(18.3,2.4,1,1,0,0,0,18.3,2.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_14, new cjs.Rectangle(0,0.1,36.2,4.7), null);


(lib.ClipGroup_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiRAbIAAg1IEiAAIAAA1g");
	mask.setTransform(14.7,2.7);

	// Layer_3
	this.instance = new lib.ClipGroup_13();
	this.instance.parent = this;
	this.instance.setTransform(14.7,2.9,1,1,0,0,0,14.7,2.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_12, new cjs.Rectangle(0.1,0,29.1,5.5), null);


(lib.ClipGroup_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhyAPIgSgEQgLgKgBgOIgBgNIASABQASAAApAHQAoAIAWAAQBIAAA0gPIANgBIAOAAQAAAGgCAIQgFAMgIALIgIACIgHACIgMADQg3AJgzAAQg9AAgygMg");
	mask.setTransform(14.6,2.8);

	// Layer_3
	this.instance = new lib.ClipGroup_12();
	this.instance.parent = this;
	this.instance.setTransform(14.6,2.9,1,1,0,0,0,14.7,2.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_11, new cjs.Rectangle(0,0.1,29.1,5.4), null);


(lib.ClipGroup_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiRAbIAAg1IEjAAIAAA1g");
	mask.setTransform(14.6,2.8);

	// Layer_3
	this.instance = new lib.ClipGroup_11();
	this.instance.parent = this;
	this.instance.setTransform(14.7,2.9,1,1,0,0,0,14.6,2.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10, new cjs.Rectangle(0,0.1,29.2,5.4), null);


(lib.ClipGroup_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AliDNIAAmZILFAAIAAGZg");
	mask.setTransform(35.6,20.8);

	// Layer_3
	this.instance = new lib.ClipGroup_9();
	this.instance.parent = this;
	this.instance.setTransform(35.8,20.9,1,1,0,0,0,35.8,20.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8, new cjs.Rectangle(0.1,0.4,71,40.9), null);


(lib.ClipGroup_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhdDIQgqgFgCgHQAAgEgDgHQgCgGgIgMQgJgKgGgEQgogZgbgaQgmglgZgvQgcgzgRhLQgMg0gCgkQAMAWBqALQBiALCIAAQCXAABogNQBcgMAKgTQAAAdgRBEQgUBQgWAlQgeAygcAcQgVAVguAfQgOAJgHALQgIAKgCAHQgCAIABADQgGAIgqAEQgnAFg2AAQg0AAgngFg");
	mask.setTransform(35.5,20.5);

	// Layer_3
	this.instance = new lib.ClipGroup_8();
	this.instance.parent = this;
	this.instance.setTransform(35.7,20.6,1,1,0,0,0,35.8,20.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7, new cjs.Rectangle(0,0,71,41), null);


(lib.ClipGroup_5copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AljBrIAAjVILHAAIAADVg");
	mask.setTransform(36,10.7);

	// Layer_3
	this.instance = new lib.ClipGroup_6();
	this.instance.parent = this;
	this.instance.setTransform(36,10.8,1,1,0,0,0,36,10.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5copy, new cjs.Rectangle(0.4,0.1,71.1,21.3), null);


(lib.ClipGroup_3copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjBAVIAAgpIGDAAIAAApg");
	mask.setTransform(19.4,2.1);

	// Layer_3
	this.instance = new lib.ClipGroup_4copy();
	this.instance.parent = this;
	this.instance.setTransform(19.4,2.1,1,1,0,0,0,19.3,2.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3copy, new cjs.Rectangle(0.1,0,38.7,4.3), null);


(lib.ClipGroup_1copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjDAVIAAgpIGHAAIAAApg");
	mask.setTransform(19.6,2.1);

	// Layer_3
	this.instance = new lib.ClipGroup_2copy();
	this.instance.parent = this;
	this.instance.setTransform(19.6,2.1,1,1,0,0,0,19.6,2.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1copy, new cjs.Rectangle(0,0,39.2,4.3), null);


(lib.ClipGroup_1_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ABxBmIiCgKQhPgHgygDQhLgEhPAAQgohKgOhAQgBgWCEgNQBrgLBxAAQB6AABjAKQCFAMAEAYQgKAhgcA0IgvBSQhPAAhOgFg");
	mask.setTransform(35.7,10.7);

	// Layer_3
	this.instance = new lib.ClipGroup_5copy();
	this.instance.parent = this;
	this.instance.setTransform(35.6,10.8,1,1,0,0,0,36,10.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_0, new cjs.Rectangle(0.2,0,71,21.4), null);


(lib.Scene_1_Layer_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.third_moveitems = new lib.third_moveitems();
	this.third_moveitems.name = "third_moveitems";
	this.third_moveitems.parent = this;
	this.third_moveitems.setTransform(164.3,213.2,1,1,0,0,0,-40,56);
	this.third_moveitems.visible = false;
	new cjs.ButtonHelper(this.third_moveitems, 0, 1, 1);

	this.mybeks = new lib.mybeksss();
	this.mybeks.name = "mybeks";
	this.mybeks.parent = this;
	this.mybeks.setTransform(165.4,210,3.08,3.08,0,0,0,0.1,0.1);
	this.mybeks.visible = false;

	this.beckr = new lib.mybeksss();
	this.beckr.name = "beckr";
	this.beckr.parent = this;
	this.beckr.setTransform(394.6,308.7,3.08,3.08,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.beckr},{t:this.mybeks},{t:this.third_moveitems}]}).wait(2));

}).prototype = p = new cjs.MovieClip();


(lib.Group_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_1copy();
	this.instance.parent = this;
	this.instance.setTransform(19.6,2.1,1,1,0,0,0,19.6,2.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_7, new cjs.Rectangle(0,0,39.2,4.3), null);


(lib.Group_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_3copy();
	this.instance.parent = this;
	this.instance.setTransform(19.4,2.1,1,1,0,0,0,19.4,2.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_6, new cjs.Rectangle(0,0,38.7,4.3), null);


(lib.Group_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_10();
	this.instance.parent = this;
	this.instance.setTransform(14.6,2.9,1,1,0,0,0,14.6,2.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_5, new cjs.Rectangle(0,0,29.3,5.8), null);


(lib.Group_4copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_14();
	this.instance.parent = this;
	this.instance.setTransform(18.3,2.4,1,1,0,0,0,18.3,2.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_4copy, new cjs.Rectangle(0,-0.3,36.5,5.3), null);


(lib.Group_3copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_18();
	this.instance.parent = this;
	this.instance.setTransform(4,3.1,1,1,0,0,0,4,3.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3copy, new cjs.Rectangle(0,-0.2,8.2,6.7), null);


(lib.Group_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_22();
	this.instance.parent = this;
	this.instance.setTransform(3.6,3.1,1,1,0,0,0,3.6,3.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2, new cjs.Rectangle(-0.4,-0.2,8.2,6.7), null);


(lib.Group_1_0copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_30();
	this.instance.parent = this;
	this.instance.setTransform(30.9,11.4,1,1,0,0,0,30.9,11.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1_0copy, new cjs.Rectangle(-0.1,-0.3,61.9,23.5), null);


(lib.Group = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_34();
	this.instance.parent = this;
	this.instance.setTransform(13.9,16.4,1,1,0,0,0,13.9,16.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(0,-0.4,27.9,33.6), null);


(lib.ClipGroup_26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AliDNIAAmZILFAAIAAGZg");
	mask.setTransform(35.5,20.5);

	// Layer_3
	this.instance = new lib.Group();
	this.instance.parent = this;
	this.instance.setTransform(52.1,19.8,1,1,0,0,0,13.9,16.4);
	this.instance.alpha = 0.398;

	this.instance_1 = new lib.Group_1_0copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(36.5,23.9,1,1,0,0,0,30.9,11.4);
	this.instance_1.alpha = 0.18;

	this.instance_2 = new lib.ClipGroup_27();
	this.instance_2.parent = this;
	this.instance_2.setTransform(35.5,20.5,1,1,0,0,0,35.5,20.5);

	var maskedShapeInstanceList = [this.instance,this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_26, new cjs.Rectangle(0,0,71,41), null);


(lib.Group_1copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_26();
	this.instance.parent = this;
	this.instance.setTransform(35.5,20.5,1,1,0,0,0,35.5,20.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1copy, new cjs.Rectangle(-0.2,-0.3,71.5,41.8), null);


(lib.Symbol1copy15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_1
	this.text = new cjs.Text("Mg", "19px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 49;
	this.text.parent = this;
	this.text.setTransform(35.5,35.9,1,0.86);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(2));

	// MergedLayer_3
	this.instance = new lib.Group_0();
	this.instance.parent = this;
	this.instance.setTransform(35.2,43,1,1,0,0,0,33,7);
	this.instance.alpha = 0.621;

	this.instance_1 = new lib.Group_1copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(35.7,42.6,1,1,0,0,0,35.5,20.5);
	this.instance_1.alpha = 0.59;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(2));

	// MergedLayer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["test_1_atlas_"],20), null, new cjs.Matrix2D(-0.332,0,0,0.485,32,-32.7)).s().p("Ak/FHIAAqNIJ/AAIAAIsIh2AAIAABhg");
	this.shape.setTransform(35.5,23);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(1));

	// MergedLayer_2
	this.instance_2 = new lib.Group_2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(50,59.6,1,1,0,0,0,3.6,3.1);
	this.instance_2.alpha = 0.148;

	this.instance_3 = new lib.Group_3copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(20.8,59.7,1,1,0,0,0,4,3.1);
	this.instance_3.alpha = 0.148;

	this.instance_4 = new lib.Group_4copy();
	this.instance_4.parent = this;
	this.instance_4.setTransform(36,58.1,1,1,0,0,0,18.3,2.4);
	this.instance_4.alpha = 0.148;

	this.instance_5 = new lib.Group_5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(35.7,61.2,1,1,0,0,0,14.6,2.9);
	this.instance_5.alpha = 0.398;

	this.instance_6 = new lib.ClipGroup_7();
	this.instance_6.parent = this;
	this.instance_6.setTransform(35.6,43.6,1,1,0,0,0,35.6,20.5);

	this.instance_7 = new lib.ClipGroup_1_0();
	this.instance_7.parent = this;
	this.instance_7.setTransform(35.4,28.8,1,1,0,0,0,35.6,10.8);

	this.instance_8 = new lib.Group_6();
	this.instance_8.parent = this;
	this.instance_8.setTransform(26.9,62.8,1,1,0,0,0,19.4,2.1);
	this.instance_8.alpha = 0.148;

	this.instance_9 = new lib.Group_7();
	this.instance_9.parent = this;
	this.instance_9.setTransform(44.2,62.8,1,1,0,0,0,19.6,2.1);
	this.instance_9.alpha = 0.148;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]}).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,-9.7,72,74.6);


(lib.Symbol1copy10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(7));

	// Layer_1
	this.text = new cjs.Text(" ماغنسويم", "18px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(32.9,66.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#B7B7B7").ss(1,1,1).p("Akxh4IJjAAIAADxIpjAAg");
	this.shape.setTransform(32.7,77.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B7B7B7").s().p("AkxB5IAAjxIJjAAIAADxg");
	this.shape_1.setTransform(32.7,77.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text}]},1).wait(6));

	// Layer_1
	this.text_1 = new cjs.Text("Mg", "19px 'Arial'");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 49;
	this.text_1.parent = this;
	this.text_1.setTransform(35.5,35.9,1,0.86);

	this.timeline.addTween(cjs.Tween.get(this.text_1).wait(7));

	// MergedLayer_3
	this.instance = new lib.Group_0();
	this.instance.parent = this;
	this.instance.setTransform(35.2,43,1,1,0,0,0,33,7);
	this.instance.alpha = 0.621;

	this.instance_1 = new lib.Group_1copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(35.7,42.6,1,1,0,0,0,35.5,20.5);
	this.instance_1.alpha = 0.59;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(7));

	// MergedLayer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(cjs.SpriteSheetUtils.extractFrame(ss["test_1_atlas_"],20), null, new cjs.Matrix2D(-0.332,0,0,0.485,32,-32.7)).s().p("Ak/FHIAAqNIJ/AAIAAIsIh2AAIAABhg");
	this.shape_2.setTransform(35.5,23);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(7));

	// MergedLayer_2
	this.instance_2 = new lib.Group_2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(50,59.6,1,1,0,0,0,3.6,3.1);
	this.instance_2.alpha = 0.148;

	this.instance_3 = new lib.Group_3copy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(20.8,59.7,1,1,0,0,0,4,3.1);
	this.instance_3.alpha = 0.148;

	this.instance_4 = new lib.Group_4copy();
	this.instance_4.parent = this;
	this.instance_4.setTransform(36,58.1,1,1,0,0,0,18.3,2.4);
	this.instance_4.alpha = 0.148;

	this.instance_5 = new lib.Group_5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(35.7,61.2,1,1,0,0,0,14.6,2.9);
	this.instance_5.alpha = 0.398;

	this.instance_6 = new lib.ClipGroup_7();
	this.instance_6.parent = this;
	this.instance_6.setTransform(35.6,43.6,1,1,0,0,0,35.6,20.5);

	this.instance_7 = new lib.ClipGroup_1_0();
	this.instance_7.parent = this;
	this.instance_7.setTransform(35.4,28.8,1,1,0,0,0,35.6,10.8);

	this.instance_8 = new lib.Group_6();
	this.instance_8.parent = this;
	this.instance_8.setTransform(26.9,62.8,1,1,0,0,0,19.4,2.1);
	this.instance_8.alpha = 0.148;

	this.instance_9 = new lib.Group_7();
	this.instance_9.parent = this;
	this.instance_9.setTransform(44.2,62.8,1,1,0,0,0,19.6,2.1);
	this.instance_9.alpha = 0.148;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]}).wait(7));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,-9.7,72,74.6);


(lib.Symbol35copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.text = new cjs.Text(" ماغنسويم", "18px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(35.7,93.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#B7B7B7").ss(1,1,1).p("Akxh4IJjAAIAADxIpjAAg");
	this.shape.setTransform(35.5,104.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B7B7B7").s().p("AkxB5IAAjxIJjAAIAADxg");
	this.shape_1.setTransform(35.5,104.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text}]},1).wait(1));

	// Layer_1
	this.instance = new lib.Symbol1copy15();
	this.instance.parent = this;
	this.instance.setTransform(35.4,42.7,1,1,0,0,0,35.4,33);

	this.tabc_1 = new lib.Symbol1copy10();
	this.tabc_1.name = "tabc_1";
	this.tabc_1.parent = this;
	this.tabc_1.setTransform(37.5,51.4,1.878,1.505,0,0,0,35.3,33);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.tabc_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,0,72,74.6);


(lib.Scene_1_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.becker_1 = new lib.Symbol46();
	this.becker_1.name = "becker_1";
	this.becker_1.parent = this;
	this.becker_1.setTransform(734.4,318.8,1.05,1.049,0,0,0,29.4,29.2);
	new cjs.ButtonHelper(this.becker_1, 0, 1, 1);

	this.myhand = new lib.Symbol4_1();
	this.myhand.name = "myhand";
	this.myhand.parent = this;
	this.myhand.setTransform(469.2,162,0.296,0.289,0,0,0,0.1,0.4);

	this.mymg = new lib.Symbol35copy4();
	this.mymg.name = "mymg";
	this.mymg.parent = this;
	this.mymg.setTransform(624,192.9,1.05,1.049,0,0,0,36.1,38.1);
	new cjs.ButtonHelper(this.mymg, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.mymg},{t:this.myhand},{t:this.becker_1}]}).wait(2));

}).prototype = p = new cjs.MovieClip();


// stage content:
(lib.test_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.___GetDepth___ = function(obj) {
		var depth = obj.depth;
		var cameraObj = this.___camera___instance;
		if(cameraObj && cameraObj.depth && obj.isAttachedToCamera)
		{
			depth += depth + cameraObj.depth;
		}
		return depth;
		}
	this.___needSorting___ = function() {
		for (var i = 0; i < this.getNumChildren() - 1; i++)
		{
			var prevDepth = this.___GetDepth___(this.getChildAt(i));
			var nextDepth = this.___GetDepth___(this.getChildAt(i + 1));
			if (prevDepth < nextDepth)
				return true;
		}
		return false;
	}
	this.___sortFunction___ = function(obj1, obj2) {
		return (this.exportRoot.___GetDepth___(obj2) - this.exportRoot.___GetDepth___(obj1));
	}
	this.on('tick', function (event){
		var curTimeline = event.currentTarget;
		if (curTimeline.___needSorting___()){
			this.sortChildren(curTimeline.___sortFunction___);
		}
	});

	// timeline functions:
	this.frame_0 = function() {
		this.text_body = this.Actions.text_body;
		this.mytext_note = this.Actions.mytext_note;
		this.hotp_1 = this.Layer_6.hotp_1;
		this.water_point = this.Layer_7.water_point;
		this.water_cover = this.Layer_7.water_cover;
		this.start_1 = this.Layer_2.start_1;
		this.beckr = this.Layer_3.beckr;
		this.mybeks = this.Layer_3.mybeks;
		this.third_moveitems = this.Layer_3.third_moveitems;
		this.mymg = this.Layer_1.mymg;
		this.myhand = this.Layer_1.myhand;
		this.becker_1 = this.Layer_1.becker_1;
		this.peace_mg = this.Layer_5.peace_mg;
		this.hanfi_1 = this.Layer_5.hanfi_1;
		this.addEventListener("tick", fl_CustomMouseCursor.bind(this));
		function fl_CustomMouseCursor() {
			var p = this.globalToLocal(stage.mouseX, stage.mouseY);
			this.myhand.x = p.x;
			this.myhand.y = p.y;
			// canvas.style.cursor = "none";
		}
		
		
		
		/* add mg */ 
		
		this.mymg.addEventListener("mousedown", starter_mg.bind(this));
		
		function starter_mg() {	
			this.myhand.gotoAndStop(9);
			this.hotp_1.visible = true;
		
		}
		
		this.stage.addEventListener("click", startest1.bind(this));
		function startest1(){
			if(this.myhand.currentFrame == 9){
		
			this.myhand.gotoAndStop(0);
			this.hotp_1.visible = false;
		
			}
		}
		
		let water_index = 0;
		this.hotp_1.addEventListener("click", startehotp_2.bind(this));
		function startehotp_2(){
			this.myhand.gotoAndStop(0);
			this.beckr.gotoAndPlay(11);
			this.hotp_1.visible = false;
			this.water_cover.visible = true;
			this.water_point.visible = true;
			if (this.myhand.currentFrame == 0 && this.water_cover.visible == true) {
				this.beckr.addEventListener("click", secondmove.bind(this));
				
				
				function secondmove() {
					
				  	this.myhand.gotoAndStop(10);
				    this.beckr.visible = false;
					this.water_point.addEventListener("mousedown", thirdmove.bind(this));
					function thirdmove() {
					  if(this.myhand.currentFrame == 10){
			            this.mybeks.visible = true;
					    this.third_moveitems.visible = true;
			            this.myhand.gotoAndStop(0);
			            this.water_point.visible = false;
						this.water_cover.visible = false;
		                this.hanfi_1.addEventListener("mousedown", finalmove.bind(this));
						function finalmove() {
					  if ( water_index == 0) {	
						this.hanfi_1.gotoAndPlay(1);
					    this.mybeks.gotoAndPlay(1);
						this.mytext_note.visible = true;
						this.text_body.visible = true;	
					    water_index += 1;
					  } else {
						  this.mytext_note.visible = false;
						  this.text_body.visible = false;
						  this.mybeks.gotoAndPlay(1);
						  this.hanfi_1.gotoAndPlay(1);
						 
		}			  
							
						}
			          }
					
					}
					
					
				}
				
			}
			
		}
	}
	this.frame_1 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Actions_obj_
	this.Actions = new lib.Scene_1_Actions();
	this.Actions.name = "Actions";
	this.Actions.parent = this;
	this.Actions.setTransform(168.5,429.5,1,1,0,0,0,168.5,429.5);
	this.Actions.depth = 0;
	this.Actions.isAttachedToCamera = 0
	this.Actions.isAttachedToMask = 0
	this.Actions.layerDepth = 0
	this.Actions.layerIndex = 0
	this.Actions.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Actions).wait(2));

	// Layer_6_obj_
	this.Layer_6 = new lib.Scene_1_Layer_6();
	this.Layer_6.name = "Layer_6";
	this.Layer_6.parent = this;
	this.Layer_6.setTransform(391.2,236.6,1,1,0,0,0,391.2,236.6);
	this.Layer_6.depth = 0;
	this.Layer_6.isAttachedToCamera = 0
	this.Layer_6.isAttachedToMask = 0
	this.Layer_6.layerDepth = 0
	this.Layer_6.layerIndex = 1
	this.Layer_6.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_6).wait(2));

	// Layer_7_obj_
	this.Layer_7 = new lib.Scene_1_Layer_7();
	this.Layer_7.name = "Layer_7";
	this.Layer_7.parent = this;
	this.Layer_7.setTransform(167.8,305.4,1,1,0,0,0,167.8,305.4);
	this.Layer_7.depth = 0;
	this.Layer_7.isAttachedToCamera = 0
	this.Layer_7.isAttachedToMask = 0
	this.Layer_7.layerDepth = 0
	this.Layer_7.layerIndex = 2
	this.Layer_7.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_7).wait(2));

	// Layer_2_obj_
	this.Layer_2 = new lib.Scene_1_Layer_2();
	this.Layer_2.name = "Layer_2";
	this.Layer_2.parent = this;
	this.Layer_2.setTransform(451.4,49,1,1,0,0,0,451.4,49);
	this.Layer_2.depth = 0;
	this.Layer_2.isAttachedToCamera = 0
	this.Layer_2.isAttachedToMask = 0
	this.Layer_2.layerDepth = 0
	this.Layer_2.layerIndex = 3
	this.Layer_2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_2).wait(2));

	// Layer_3_obj_
	this.Layer_3 = new lib.Scene_1_Layer_3();
	this.Layer_3.name = "Layer_3";
	this.Layer_3.parent = this;
	this.Layer_3.setTransform(279.8,254.7,1,1,0,0,0,279.8,254.7);
	this.Layer_3.depth = 0;
	this.Layer_3.isAttachedToCamera = 0
	this.Layer_3.isAttachedToMask = 0
	this.Layer_3.layerDepth = 0
	this.Layer_3.layerIndex = 4
	this.Layer_3.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_3).wait(2));

	// Layer_1_obj_
	this.Layer_1 = new lib.Scene_1_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(612.7,238.5,1,1,0,0,0,612.7,238.5);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 5
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(2));

	// Layer_5_obj_
	this.Layer_5 = new lib.Scene_1_Layer_5();
	this.Layer_5.name = "Layer_5";
	this.Layer_5.parent = this;
	this.Layer_5.setTransform(349.3,144.1,1,1,0,0,0,349.3,144.1);
	this.Layer_5.depth = 0;
	this.Layer_5.isAttachedToCamera = 0
	this.Layer_5.isAttachedToMask = 0
	this.Layer_5.layerDepth = 0
	this.Layer_5.layerIndex = 6
	this.Layer_5.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_5).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(428.7,292.3,727.6,476.8);
// library properties:
lib.properties = {
	id: '36B2455CA1594049987AFB13C9483E16',
	width: 800,
	height: 600,
	fps: 24,
	color: "#333333",
	opacity: 1.00,
	manifest: [
		{src:"images/test_1_atlas_.png?1591002407381", id:"test_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['36B2455CA1594049987AFB13C9483E16'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


// Layer depth API : 

AdobeAn.Layer = new function() {
	this.getLayerZDepth = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth; else 0;";
		return eval(script);
	}
	this.setLayerZDepth = function(timeline, layerName, zDepth)
	{
		const MAX_zDepth = 10000;
		const MIN_zDepth = -5000;
		if(zDepth > MAX_zDepth)
			zDepth = MAX_zDepth;
		else if(zDepth < MIN_zDepth)
			zDepth = MIN_zDepth;
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth = " + zDepth + ";";
		eval(script);
	}
	this.removeLayer = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline.removeChild(timeline." + layerName + ");";
		eval(script);
	}
	this.addNewLayer = function(timeline, layerName, zDepth)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		zDepth = typeof zDepth !== 'undefined' ? zDepth : 0;
		var layer = new createjs.MovieClip();
		layer.name = layerName;
		layer.depth = zDepth;
		layer.layerIndex = 0;
		timeline.addChild(layer);
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;